scGSEA package
==============

Submodules
----------

scGSEA.preprocess module
------------------------

.. automodule:: scGSEA.preprocess
   :members:
   :undoc-members:
   :show-inheritance:

scGSEA.scgsea module
--------------------

.. automodule:: scGSEA.scgsea
   :members:
   :undoc-members:
   :show-inheritance:

scGSEA.scgsea\_helper module
----------------------------

.. automodule:: scGSEA.scgsea_helper
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: scGSEA
   :members:
   :undoc-members:
   :show-inheritance:
