.. scGSEA documentation master file, created by
   sphinx-quickstart on Thu Jul 20 09:37:25 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Tutorial
==================================
.. note:: Please make sure you are looking at the documentation that
	  matches the version of the software you are using. See the
	  version label at the top of the navigation panel on the left.
	  You can change it using selector at the bottom of that
	  navigation panel.

The scGSEA package is available on GenePattern and a notebook comprising of analysis steps is available on GenePattern Notebook website.